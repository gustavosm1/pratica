
# Projeto Final — Processamento de Imagens: HOG + SVM com Coffee Beans

## 👤 Equipe
- Gustavo Machado

## 🧠 Descritor Implementado
- **HOG (Histogram of Oriented Gradients):** utilizado para extrair padrões de borda, textura e forma dos grãos de café. O HOG analisa a direção dos gradientes em regiões da imagem, destacando estruturas locais.

## 🤖 Classificador Utilizado
- **SVM (Support Vector Machine)** com kernel linear.

## 🎯 Resultados Obtidos
- Os resultados da classificação incluem **acurácia**, **matriz de confusão**, **precisão**, **recall** e **F1-score**, exibidos ao final da execução do notebook.

## 📂 Repositório do Projeto
- GitHub: [https://github.com/gustavosm1/pratica](https://github.com/gustavosm1/pratica)

## ▶️ Executar no Google Colab
- [Abrir no Google Colab](https://colab.research.google.com/github/gustavosm1/pratica/blob/main/classificacao_cafe_hog_svm_gustavo.ipynb)

## 📝 Instruções de Uso
1. Acesse o link do notebook ou abra o arquivo `Projeto_HOG_SVM_OK_FINAL.ipynb` no Google Colab.
2. Clique em “Executar tudo” para iniciar a análise.
3. O dataset corrigido `coffee_dataset_corrigido.zip` pode ser extraído em `/content/train/` ou `/mnt/data/`.
4. Ao final, os resultados serão exibidos com os principais indicadores de desempenho.

---

**Observação:**  
O projeto segue a abordagem clássica exigida pelo enunciado, com uso de um descritor não abordado em aula (HOG) e classificador tradicional (SVM). As bibliotecas utilizadas incluem OpenCV, NumPy, Matplotlib e Scikit-learn.
