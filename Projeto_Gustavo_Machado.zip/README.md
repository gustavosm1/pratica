
# Classificação de Grãos de Café com HOG + LBP

## Equipe  
Gustavo Machado

## Descrição dos descritores implementados  
- **HOG (Histogram of Oriented Gradients):** extrai padrões de bordas e gradientes em regiões da imagem.
- **LBP (Local Binary Pattern):** extrai textura local com base em vizinhança de pixels.

## Dataset utilizado  
[Coffee Bean Dataset (224x224)](https://www.kaggle.com/datasets/gpiosenka/coffee-bean-dataset-resized-224-x-224)

## Repositório do projeto  
[Link para Google Drive ou outro repositório com código + vídeo]()

## Classificadores utilizados e acurácia  
- **SVM (Support Vector Machine)**  
  - Kernel: linear  
  - Acurácia aproximada: ~X% (completar após execução)  
- **Random Forest**  
  - Estimadores: 100  
  - Acurácia aproximada: ~Y% (completar após execução)  

## Instruções de uso  
1. Suba o `.zip` do dataset manualmente no Colab.  
2. Execute todas as células do notebook.  
3. Os resultados são mostrados ao final, com métricas e matrizes de confusão.
